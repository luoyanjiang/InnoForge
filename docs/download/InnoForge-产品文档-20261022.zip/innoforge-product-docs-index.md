# InnoForge 产品文档总索引

**更新**：2026-10-23  
**阅读顺序（现行权威）**：① 讨论文档 → ② 产品方案 → ③ UI 设计 → ④ 活文档 / 外部系统 → ⑤ 历史与实现计划  

主仓实现：[luoyanjiang/InnoForge](https://github.com/luoyanjiang/InnoForge)

---

## A. 现行权威（请优先读）

| 文档 | 路径 | 说明 |
|------|------|------|
| 讨论文档 v0.4 | [AI创新创造研究系统_讨论文档_v0.4.md](/cursor/stores/self/docs/AI创新创造研究系统_讨论文档_v0.4.md) · [docx](/cursor/stores/self/docs/AI创新创造研究系统_讨论文档_v0.4.docx) | 输入愿景与架构讨论 |
| **产品方案 v0.4** | [innoforge-product-方案-v04.md](/cursor/stores/self/docs/innoforge-product-方案-v04.md) | **已批准** · 对象模型（项目含任务；个人任务=视图） |
| **UI 设计 v0.4** | [innoforge-ui-design-v04.md](/cursor/stores/self/docs/innoforge-ui-design-v04.md) | **设计完成** · 待批准后技术设计+实现 |
| 产品设计（活文档） | [innoforge-product-design.md](/cursor/stores/self/docs/innoforge-product-design.md) | v1.8 · Intent OS × InnoForge 整合 |
| 外部系统版图 | [innoforge-external-systems.md](/cursor/stores/self/docs/innoforge-external-systems.md) | 适配器分层 · 接口占位+模拟 |

---

## B. 源材料（早期）

| 文档 | 路径 |
|------|------|
| Intent OS 产品方案 | [Intent-OS-产品方案.md](/cursor/stores/self/docs/Intent-OS-产品方案.md) |
| Intent OS 交互稿 | [intent-os-full.html](/cursor/stores/self/docs/intent-os-full.html) |
| InnoForge 产品设计更新版 | [InnoForge-产品设计文档-更新版.md](/cursor/stores/self/docs/InnoForge-产品设计文档-更新版.md) |
| InnoForge 商业计划分析 | [InnoForge-商业计划分析文档.md](/cursor/stores/self/docs/InnoForge-商业计划分析文档.md) |

---

## C. 计划与差距（执行用）

| 文档 | 路径 |
|------|------|
| 设计 vs 实现（G1–G14） | [innoforge-design-vs-impl-plan.md](/cursor/stores/self/docs/innoforge-design-vs-impl-plan.md) |
| v0.4 改进计划 | [innoforge-research-system-v04-plan.md](/cursor/stores/self/docs/innoforge-research-system-v04-plan.md) |
| UI 还原度 / F1 纠错 | [innoforge-v04-ui-fidelity-plan.md](/cursor/stores/self/docs/innoforge-v04-ui-fidelity-plan.md) |
| 独立仓库方案 A | [innoforge-repo-split-plan.md](/cursor/stores/self/docs/innoforge-repo-split-plan.md) |
| 在 PXN 上开发（历史） | [innoforge-on-pxn-plan.md](/cursor/stores/self/docs/innoforge-on-pxn-plan.md) |

---

## D. 历史实现切片计划（可归档阅读）

| 文档 | 路径 |
|------|------|
| Intent OS 原型计划 | [intent-os-prototype-plan.md](/cursor/stores/self/docs/intent-os-prototype-plan.md) |
| 设计更新计划 | [innoforge-design-update-plan.md](/cursor/stores/self/docs/innoforge-design-update-plan.md) |
| 后续步骤 1→2→3 | [innoforge-next-steps-plan.md](/cursor/stores/self/docs/innoforge-next-steps-plan.md) |
| 剩余实现 | [innoforge-remaining-impl-plan.md](/cursor/stores/self/docs/innoforge-remaining-impl-plan.md) |
| 外部依赖剩余 | [innoforge-external-remaining-plan.md](/cursor/stores/self/docs/innoforge-external-remaining-plan.md) |
| PXN UI gaps | [innoforge-pxn-ui-gaps-plan.md](/cursor/stores/self/docs/innoforge-pxn-ui-gaps-plan.md) |
| PXN continue | [innoforge-pxn-continue-plan.md](/cursor/stores/self/docs/innoforge-pxn-continue-plan.md) |
| 机器人 FK | [innoforge-pxn-robot-fk-plan.md](/cursor/stores/self/docs/innoforge-pxn-robot-fk-plan.md) |
| 官方调度 HTTP | [innoforge-pxn-dispatch-http-plan.md](/cursor/stores/self/docs/innoforge-pxn-dispatch-http-plan.md) |

---

## E. 偏好

| 文档 | 路径 |
|------|------|
| Project preferences | [preferences.md](/cursor/stores/self/preferences.md) |
